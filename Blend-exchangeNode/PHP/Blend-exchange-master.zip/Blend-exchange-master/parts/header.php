    <head>
        <title>Blend-exchange</title>
        <link rel="stylesheet" media="screen" href="main.css" />
        <link rel="shortcut icon" href="/favicon.ico">
    </head>
    <body>
        <div id="nav">
            <div id="logo">
                <span class="logoOrange">Blend</span><span class="logoBlue">-exchange</span>
                <div><a class="logoCredit" href="http://blender.stackexchange.com/users/3127/giantcowfilms">-By GiantCowFilms</a></div>
            </div>
                <ul id="navLinks">
                    <li> - About</li>
                    <li> - Contribute</li>
                    <li>Help</li>
                </ul>
        </div>